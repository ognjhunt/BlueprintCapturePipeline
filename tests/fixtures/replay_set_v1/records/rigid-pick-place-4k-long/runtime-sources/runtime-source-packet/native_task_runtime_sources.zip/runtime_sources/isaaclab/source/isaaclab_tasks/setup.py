from setuptools import setup; setup(name='isaaclab_tasks', install_requires=[])
