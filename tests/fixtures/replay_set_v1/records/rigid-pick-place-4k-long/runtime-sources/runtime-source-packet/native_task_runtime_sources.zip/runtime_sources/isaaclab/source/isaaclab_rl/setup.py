from setuptools import setup; setup(name='isaaclab_rl', install_requires=[])
