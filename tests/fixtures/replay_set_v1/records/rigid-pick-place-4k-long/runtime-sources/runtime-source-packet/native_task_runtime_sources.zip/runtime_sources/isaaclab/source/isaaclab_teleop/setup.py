from setuptools import setup; setup(name='isaaclab_teleop', install_requires=[])
