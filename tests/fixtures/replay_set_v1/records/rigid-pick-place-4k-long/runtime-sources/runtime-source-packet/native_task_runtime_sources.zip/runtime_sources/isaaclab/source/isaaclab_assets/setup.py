from setuptools import setup; setup(name='isaaclab_assets', install_requires=[])
