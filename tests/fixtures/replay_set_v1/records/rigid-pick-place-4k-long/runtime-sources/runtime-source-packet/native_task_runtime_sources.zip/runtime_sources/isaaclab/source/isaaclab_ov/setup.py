from setuptools import setup; setup(name='isaaclab_ov', install_requires=[])
