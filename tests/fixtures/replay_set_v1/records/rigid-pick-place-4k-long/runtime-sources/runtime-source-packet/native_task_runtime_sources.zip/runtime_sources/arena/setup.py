from setuptools import setup; setup(name='isaaclab_arena')
