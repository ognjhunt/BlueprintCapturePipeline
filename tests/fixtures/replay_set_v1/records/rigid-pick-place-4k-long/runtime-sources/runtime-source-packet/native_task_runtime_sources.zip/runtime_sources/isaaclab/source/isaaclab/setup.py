from setuptools import setup; setup(name='isaaclab', install_requires=['warp-lang==1.13.0', 'torch>=2.10'])
