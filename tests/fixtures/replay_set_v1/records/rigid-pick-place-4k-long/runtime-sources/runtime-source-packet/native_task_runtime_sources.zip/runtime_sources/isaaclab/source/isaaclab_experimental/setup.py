from setuptools import setup; setup(name='isaaclab_experimental', install_requires=[])
