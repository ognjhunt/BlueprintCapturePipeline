from setuptools import setup; setup(name='isaaclab_tasks_experimental', install_requires=[])
