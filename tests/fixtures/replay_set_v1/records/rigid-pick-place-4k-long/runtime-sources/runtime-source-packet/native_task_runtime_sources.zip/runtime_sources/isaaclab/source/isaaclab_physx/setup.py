from setuptools import setup; setup(name='isaaclab_physx', install_requires=[])
