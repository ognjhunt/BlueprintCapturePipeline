from setuptools import setup; setup(name='isaaclab_mimic', install_requires=[])
