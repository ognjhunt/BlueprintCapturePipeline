from setuptools import setup; setup(name='isaaclab_visualizers', install_requires=[])
