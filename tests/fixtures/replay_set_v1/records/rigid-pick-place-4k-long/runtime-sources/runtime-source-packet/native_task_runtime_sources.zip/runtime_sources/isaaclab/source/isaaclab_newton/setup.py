from setuptools import setup; setup(name='isaaclab_newton', install_requires=[])
