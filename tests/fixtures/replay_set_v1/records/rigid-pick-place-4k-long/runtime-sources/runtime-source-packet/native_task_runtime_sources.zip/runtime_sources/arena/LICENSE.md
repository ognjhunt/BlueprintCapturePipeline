Apache fixture
