from setuptools import setup; setup(name='isaaclab_contrib', install_requires=[])
