#!/usr/bin/env bash
set -u
RUNTIME_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUTPUT_DIR=${BLUEPRINT_VAST_PROVIDER_OUTPUT_DIR:-"$RUNTIME_DIR/../runtime_output"}
mkdir -p "$OUTPUT_DIR"
export BLUEPRINT_VAST_PROVIDER_OUTPUT_DIR="$OUTPUT_DIR"
python "$RUNTIME_DIR/wam_provider_runtime_runner.py"
runner_rc=$?
if [ ! -f "$OUTPUT_DIR/wam_runtime_result.json" ]; then
  python - "$OUTPUT_DIR/wam_runtime_result.json" "$runner_rc" <<'PY'
import json
import sys
from pathlib import Path
path = Path(sys.argv[1])
payload = {
    "schema_version": "policy_ranking_successor_cosmos_runtime.v1",
    "status": "blocked",
    "failure_class": "infrastructure_failure",
    "blockers": ["wam_runner_process_exited_without_runtime_result"],
    "runner_exit_code": int(sys.argv[2]),
    "blocked_wam_process_exited_without_result": True,
    "action_conditioned_video_rollout_generated": False,
    "evaluator_eligible": False,
}
path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
fi
exit "$runner_rc"
