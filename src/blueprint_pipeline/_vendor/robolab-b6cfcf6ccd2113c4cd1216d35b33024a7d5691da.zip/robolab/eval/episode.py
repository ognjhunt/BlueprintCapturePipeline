# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Policy episode runner for RoboLab.

This module contains the run_episode function that executes a single
policy-controlled episode given any :class:`InferenceClient` subclass.
The function stays policy-agnostic — concrete clients live under
``policies/<policy>/client.py``.

Supports multi-env: one PolicyClient per env, per-env video writers,
actions inferred per active env and stacked for env.step().
"""

import logging
import os
import re
import time
from collections import defaultdict

import cv2
import torch
from tqdm import tqdm

logger = logging.getLogger(__name__)


class TimingStats:
    """Simple timing utility for profiling code sections."""

    def __init__(self):
        self.times = defaultdict(list)
        self._start_times = {}

    def start(self, name: str):
        self._start_times[name] = time.perf_counter()

    def stop(self, name: str):
        if name in self._start_times:
            elapsed = time.perf_counter() - self._start_times[name]
            self.times[name].append(elapsed)
            del self._start_times[name]

    def to_dict(self, num_steps: int) -> dict:
        """Return timing summary as a dict for results logging."""
        d = {}
        for name, times in self.times.items():
            d[f"{name}_s"] = round(sum(times), 3)
            d[f"{name}_avg_ms"] = round(sum(times) / len(times) * 1000, 1) if times else 0
        d["wall_total_s"] = round(sum(sum(t) for t in self.times.values()), 3)
        d["it_per_sec"] = round(num_steps / d["wall_total_s"], 2) if d["wall_total_s"] > 0 else 0
        return d

from robolab.constants import VISUALIZE, get_output_dir
from robolab.core.logging.results import get_all_env_subtask_infos
from robolab.core.observations.observation_utils import unpack_image_obs, unpack_viewport_cams
from robolab.core.task.instruction import TrackedInstructionFields, primary_instruction
from robolab.core.utils.video_utils import VideoWriter
from robolab.core.world.world_state import get_world
from robolab.eval.base_client import InferenceClient


def run_episode(
    env,
    env_cfg,
    episode,
    client: InferenceClient,
    *,
    headless=False,
    save_videos=True,
    video_mode="all",
    enable_gt_state=False,
):
    """Run a policy-controlled episode across all parallel envs.

    The policy client is constructed by the caller (typically a per-policy
    runner under ``policies/<policy>/run.py``). This function stays
    policy-agnostic.

    Args:
        env: The environment instance (RobolabEnv with num_envs >= 1)
        env_cfg: Environment configuration
        episode: Run index (each run produces num_envs episodes)
        client: Constructed inference client. One connection shared across envs
            with per-env chunk state keyed by ``env_id``.
        headless: If True, don't display video
        save_videos: If True, save per-env episode videos
        video_mode: Which videos to save: 'all', 'viewport', 'sensor', or 'none'
        enable_gt_state: Attach per-env ground-truth sim state to the obs dict
            as ``obs["gt_state"] = {env_id: state}`` each step (see
            ``robolab/eval/gt_state.py`` for the schema).

    Returns:
        tuple: (env_results, subtask_status, timing)
            env_results: per-env dicts with {env_id, success, step}
            subtask_status: list of per-step subtask info dicts
            timing: dict with wall-clock timing breakdown
    """
    timer = TimingStats()

    obs, _ = env.reset()
    obs, _ = env.reset()
    max_steps = env.max_episode_length
    video_fps = 1 / (env_cfg.sim.render_interval * env_cfg.sim.dt) # Hz
    instruction = TrackedInstructionFields(env_cfg.instruction)
    _, display_instruction = primary_instruction(env_cfg.instruction)
    # Pull action dim from the env's action manager (IsaacLab canonical),
    # falling back to the gym action space if the manager isn't available.
    action_dim = getattr(
        getattr(env, "action_manager", None),
        "total_action_dim",
        None,
    ) or env.action_space.shape[-1]

    subtask_status = []

    # Resolve and deliver policy-requested context exactly once before the
    # first inference call. Legacy clients request nothing and keep their
    # existing per-request prompt behavior.
    client.prepare_episode(episode, instruction)

    # Set up per-run HDF5 file and per-env demo indices
    if env.recorder_manager is not None and hasattr(env.recorder_manager, 'set_hdf5_file'):
        env.recorder_manager.set_hdf5_file(f"run_{episode}.hdf5")
        for env_id in range(env.num_envs):
            env.recorder_manager.set_episode_index(env_id, env_ids=[env_id])

    # Setup per-env streaming video writers
    save_sensor = save_videos and video_mode in ("all", "sensor")
    save_viewport = save_videos and video_mode in ("all", "viewport")
    cleaned_instruction = re.sub(r'[^\w\s]', '', display_instruction).replace(' ', '_')
    # Define unconditionally so the finally clause below can iterate them either way.
    video_writers_obs: list[VideoWriter] = []
    video_writers_viewport: list[VideoWriter] = []
    if save_videos:
        for env_id in range(env.num_envs):
            suffix = f"_{episode}_env{env_id}" if env.num_envs > 1 else f"_{episode}"
            if save_sensor:
                video_path = os.path.join(get_output_dir(), f"{cleaned_instruction}{suffix}.mp4")
                video_writers_obs.append(VideoWriter(video_path, video_fps))
            if save_viewport:
                video_path_viewport = os.path.join(get_output_dir(), f"{cleaned_instruction}{suffix}_viewport.mp4")
                video_writers_viewport.append(VideoWriter(video_path_viewport, video_fps))

    gt_exporter = None
    if enable_gt_state:
        try:
            from robolab.eval.gt_state import GroundTruthStateExporter

            gt_exporter = GroundTruthStateExporter(env, env_cfg)
        except Exception:
            logger.exception("Failed to initialize the GT-state exporter")

    import omni.kit.app
    import omni.timeline
    timeline = omni.timeline.get_timeline_interface()
    kit_app = omni.kit.app.get_app()

    actual_steps = 0
    try:
        for step in tqdm(range(max_steps)):

            while not timeline.is_playing():
                kit_app.update()

            # Attach per-env ground-truth state so clients that want privileged
            # sim state can pick out their env's entry (see robolab/eval/gt_state.py).
            if gt_exporter is not None:
                try:
                    obs["gt_state"] = gt_exporter.export_all(list(env.active_env_ids))
                except Exception:
                    logger.exception(
                        "GT-state export failed at step %d; disabling it for the rest of the episode. "
                        "Clients will stop receiving gt_state from this step on.", step,
                    )
                    gt_exporter = None
                    # Drop the previous step's entry rather than forwarding stale state.
                    obs.pop("gt_state", None)

            timer.start("policy_inference")
            # Infer actions for all active (non-frozen) envs in ONE call.
            # Batching-capable clients send a single request for every env
            # needing a replan; the InferenceClient default is a serial
            # loop, so other policies behave exactly as before.
            actions = torch.zeros(env.num_envs, action_dim, device=env.device)
            last_viz = None
            active_env_ids = list(env.active_env_ids)
            rets = client.infer_batch(
                obs, instruction, env_ids=active_env_ids
            )
            if set(rets) != set(active_env_ids):
                raise ValueError("Policy must return one result for every active environment")
            for env_id in sorted(rets):
                ret = rets[env_id]
                actions[env_id] = torch.tensor(ret["action"], device=env.device)
                if env_id == 0 or last_viz is None:
                    last_viz = ret.get("viz")
            timer.stop("policy_inference")

            if not headless and last_viz is not None:
                cv2.imshow(display_instruction, cv2.cvtColor(last_viz, cv2.COLOR_RGB2BGR))
                cv2.waitKey(1)

            if VISUALIZE:
                get_world(env).visualize()

            timer.start("env_step")
            obs, reward, term, trunc, info = env.step(actions)
            timer.stop("env_step")

            # Collect per-env subtask info (list of dicts, one per env)
            per_env_infos = get_all_env_subtask_infos(env)
            subtask_status.append(per_env_infos)

            # Write per-env video frames (skip frozen envs)
            if save_videos:
                timer.start("video_write")
                for env_id in range(env.num_envs):
                    if env._frozen_envs[env_id]:
                        continue
                    if save_sensor:
                        frame_obs = unpack_image_obs(obs, scale=0.5, env_id=env_id).get("combined_image")
                        video_writers_obs[env_id].write(frame_obs)
                    if save_viewport:
                        frame_vp = unpack_viewport_cams(obs, env_id=env_id).get("combined_image")
                        video_writers_viewport[env_id].write(frame_vp)
                timer.stop("video_write")

            actual_steps += 1

            # RobolabEnv freezes terminated envs and exports recordings automatically
            if env.all_terminated:
                break
    finally:
        for vw in video_writers_obs + video_writers_viewport:
            try:
                vw.release()
            except Exception:
                logger.exception("Failed to release video writer")
        try:
            client.reset()
        except Exception:
            logger.exception("Failed to reset client after episode")

    timing = timer.to_dict(actual_steps)
    env_results = env.get_env_results()
    for result in env_results:
        result["instruction_fields"] = instruction.instruction_fields
        result["instruction_fields_used"] = instruction.instruction_fields_used
    return env_results, subtask_status, timing
