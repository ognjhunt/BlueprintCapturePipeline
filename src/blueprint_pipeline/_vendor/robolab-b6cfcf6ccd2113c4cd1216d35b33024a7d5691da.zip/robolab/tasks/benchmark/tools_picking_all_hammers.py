# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from dataclasses import dataclass

import isaaclab.envs.mdp as mdp
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.utils import configclass

from robolab.core.scenes.utils import import_scene
from robolab.core.task.conditionals import object_outside_of_and_on_surface, pick_and_place_on_surface
from robolab.core.task.task import Task


@configclass
class ToolsPickingAllHammersTerminations:
    """Termination configuration for banana task."""
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    success = DoneTerm(
        func=object_outside_of_and_on_surface,
        params={"object": ["husky_hammer", "blue_hammer", "red_hammer", "wood_hammer"], "container": "left_bin", "surface": "table", "logical": "all", "tolerance": 0.0, "require_gripper_detached": True}
    )

@dataclass
class ToolsPickingAllHammersTask(Task):
    contact_object_list = ["table", "clamp", "cordless_drill", "spring_clamp", "husky_hammer", "blue_hammer", "red_hammer", "wood_hammer", "left_bin", "center_bin", "right_bin", "clamp_01"]
    scene = import_scene("tools_picking.usda", contact_object_list)
    terminations = ToolsPickingAllHammersTerminations
    instruction = {
        "default": "Take out all the hammers and put them on the table",
        "vague": "Empty the hammers bin",
        "specific": "Remove every hammer from the left bin and place each one on the table in front of you",
    }
    episode_length_s: int = 240
    attributes = ['semantics', 'spatial']

    subtasks = [
        pick_and_place_on_surface(
            object=["husky_hammer", "blue_hammer", "red_hammer", "wood_hammer"],
            surface="table",
            logical="all",
            score=1.0
        )
    ]
