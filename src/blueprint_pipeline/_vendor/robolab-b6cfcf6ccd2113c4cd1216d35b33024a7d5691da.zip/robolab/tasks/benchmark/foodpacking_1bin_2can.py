# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from dataclasses import dataclass

import isaaclab.envs.mdp as mdp
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.utils import configclass

from robolab.core.scenes.utils import import_scene
from robolab.core.task.conditionals import object_in_container, pick_and_place
from robolab.core.task.task import Task


@configclass
class FoodPacking2CansTerminations:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    success = DoneTerm(func=object_in_container, params={"object": [ "tomato_soup_can", "tuna_can"], "container": "bin_a06", "logical": "all", "require_gripper_detached": True})

@dataclass
class FoodPacking2CansTask(Task):
    contact_object_list = ["bin_a06", "cheez_it", "mustard", "sugar_box", "tomato_soup_can", "tuna_can", "table"]
    scene = import_scene("foodpacking_1bin_2box_2can.usda", contact_object_list)
    terminations = FoodPacking2CansTerminations
    instruction = {
        "default": "Pack canned foods into the bin",
        "vague": "Pack cans",
        "specific": "Pick up each canned food item and place them all inside the bin",
    }
    episode_length_s: int = 180
    attributes = ['semantics']
    subtasks = [
        pick_and_place(
            object=[ "tomato_soup_can", "tuna_can"],
            container="bin_a06",
            logical="all",
            score=1.0
        )
    ]
